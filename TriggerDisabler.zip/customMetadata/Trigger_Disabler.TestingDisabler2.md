<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Testing Disabler 2</label>
    <protected>false</protected>
    <values>
        <field>Disabled__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Method_name__c</field>
        <value xsi:type="xsd:string">global</value>
    </values>
    <values>
        <field>Trigger_Name__c</field>
        <value xsi:type="xsd:string">TestingTrigger2</value>
    </values>
</CustomMetadata>
